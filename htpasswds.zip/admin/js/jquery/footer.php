﻿<div id="footer" style="clear: both;overflow:hidden;width:1000px;height:100%;background:url(img/footer.png);margin:auto; bottom:0;">
<table border="1" width="100%" align="center">
<tr><td width="400">
<img src="img/contact_icon.png" style="float:left;padding:15px" />

<p>Հեռ: &nbsp; &nbsp; (+374-10) 54-35-76<br> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (+374-10) 54-35-78<br> Ֆաքս: (+374-10) 54-75-69 <br>Էլ. փոստ: info@eca.am <br>Հասցե: Ք. Երևան, Բաղրամյան 18</p>

</td>
<td width="250" align="center">
<div style="width:240px;color:white;text-align:center">text text text text text text text texttext text text text texttext text text text texttext text text textext text text text text</div>
<div class="pray"><span style="cursor: pointer;color:white;" onclick="window.open('pray.php','','Toolbar=1,Location=0,Directories=0,Status=0,Menubar=0,Scrollbars=0,Resizable=0,Width=700,Height=600');">Աղոթքի Խնդրանք</span></div>
</td>
<td>
<div style="width:200px;height:60px;overflow:hidden;margin-bottom:-80px;float:right"> 
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="200" height="80" id="NardiDemo" align="middle">
				<param name="movie" value="Webex Lil.swf">
				<param name="quality" value="high">
				<param name="bgcolor" value="#edb27b">
				<param name="play" value="true">
				<param name="loop" value="true">
				<param name="wmode" value="transparent">
				<param name="scale" value="showall">
				<param name="menu" value="true">
				<param name="devicefont" value="false">
				<param name="salign" value="">
				<param name="allowScriptAccess" value="sameDomain">
				<!--[if !IE]>-->
				<object type="application/x-shockwave-flash" data="Webex Lil.swf" width="200" height="80">
					<param name="movie" value="Webex Lil.swf">
					<param name="quality" value="high">
					<param name="bgcolor" value="#edb27b">
					<param name="play" value="true">
					<param name="loop" value="true">
					<param name="wmode" value="transparent">
					<param name="scale" value="showall">
					<param name="menu" value="true">
					<param name="devicefont" value="false">
					<param name="salign" value="">
					<param name="allowScriptAccess" value="sameDomain">
				<!--<![endif]-->
					<a href="http://www.adobe.com/go/getflash">
						<img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player">
					</a>
				<!--[if !IE]>-->
				</object>
				<!--<![endif]-->
			</object>


</div>
</td>
</tr>
</table>
</div>

</body>
</html>