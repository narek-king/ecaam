<!DOCTYPE html>
<html>
<head>
<META HTTP-EQUIV="REFRESH" CONTENT="0;URL=http://<?php echo $_SERVER['SERVER_NAME']; ?>">
</head>
<body>
</body>
</html>