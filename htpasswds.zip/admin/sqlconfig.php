<?

$hostname	= 'localhost';

$sqluser	= 'amaaam_eca';

$sqlpass	= '9aa+i?4POV*i';

$dbName		= 'amaaam_eca';



@mysql_connect($hostname, $sqluser, $sqlpass)  or die( 'Connexion au serveur de donn�es impossible' ) ;

@mysql_select_db( $dbName ) or die( 'Unable to connect DATABASE' ) ;

mysql_query('SET NAMES "utf8"');

?>